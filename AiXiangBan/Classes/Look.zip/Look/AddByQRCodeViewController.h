//
//  AddByQRCodeViewController.h
//  AiXiangBan
//
//  Created by 周春仕 on 2017/10/9.
//  Copyright © 2017年 周春仕. All rights reserved.
//

#import "BaseViewController.h"

@interface AddByQRCodeViewController : BaseViewController

@end
