//
//  SetDeviceNameViewController.h
//  孝相伴
//
//  Created by MAC on 17/10/10.
//  Copyright © 2017年 周春仕. All rights reserved.
//

#import "BaseViewController.h"

@interface SetDeviceNameViewController : BaseViewController

@end
