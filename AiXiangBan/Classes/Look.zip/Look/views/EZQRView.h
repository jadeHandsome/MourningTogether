//
//  EZQRView.h
//  EZOpenSDKDemo
//
//  Created by DeJohn Dong on 15/10/29.
//  Copyright © 2015年 hikvision. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface EZQRView : UIView

@property (nonatomic) IBInspectable CGSize clearSize;
@property (nonatomic, strong) IBInspectable UIColor *cornerColor;

@end
